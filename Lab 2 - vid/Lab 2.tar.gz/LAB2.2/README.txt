LAB2.2 is the sample solution of part2.
run it under QEMU
enter key from UART0 to display wsu.bmp in different resolutions
